# -*- coding: utf-8 -*-
# Aqui indicamos que se cargará el fichero "models.py"
# Si creamos más modelos, deben importarse en este fichero
from . import models